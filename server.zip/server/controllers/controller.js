import express from 'express';
import { StatusCodes } from 'http-status-codes';
import { USER } from '../models/user-model.js';



export const home = async (req, res) => {
    try {
        res.send('Hello World! this is home page of my server through controllers');
    }
    catch (error) {
        res.status(400).send('Internal Server Error');
    }
};

export const about = async (req, res) => {
    try {
        res.send('About page of my server through controllers');
    }
    catch (error) {
        res.status(400).send('Internal Server Error');
    }
};

export const contact = async (req, res) => {
    try {
        res.send('Contact page of my server through controllers');
    }
    catch (error) {
        res.status(400).send('Internal Server Error');
    }
};
export const login = async (req, res) => {
    try {
        res.send('Login page of my server through controllers');
    }
    catch (error) {
        res.status(400).send('Internal Server Error');
    }
};




export const register = async (req, res) => {
    try {
        console.log(req.body);
        const { username, email, number, password } = req.body;
        if (!username || !email || !number || !password) {
            return res.status(StatusCodes.BAD_REQUEST).json({ msg: "Please enter all the fields" });
        }
        await USER.create(req.body);
        res.status(StatusCodes.CREATED).json({ msg: "user added successfully" });
    } catch (error) {
        console.log(error);
        res.status(StatusCodes.BAD_GATEWAY).json({ msg: "Internal server error , try again" });
    }
};