import "./Footer.css";

export const Footer = () => {
  return (
    <footer>
      <p>@Zoomania360</p>
    </footer>
  );
};
