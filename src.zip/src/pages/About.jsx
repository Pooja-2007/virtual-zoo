import { NavLink } from "react-router-dom";
import { Analytics } from "../components/Analytics";
import { useAuth } from "../store/auth";

export const About = () => {
  const { user } = useAuth();
  return (
    <>
      <main>
        <section className="section-hero">
          <div className="container grid grid-two-cols">
            <div className="hero-content">
              {/* <p>We care to cure your Health</p> */}
              <p>
                Welcome,
                {user ? ` ${user.username} to our website` : ` to our website`}
              </p>
              <h1>Why Choose Us? </h1>
              <p>
                Accessibility: Our virtual zoo can be accessed from anywhere
                with an internet connection, allowing people to explore 
                wildlife without physically visiting a zoo.
              </p>
              <p>
                Convenience: Visitors can view animals at any time without
                the need to travel, making it convenient for those with busy
                schedules or limited mobility.


              </p>
              <p>
                Research Opportunities: Our virtual zoo can support research initiatives
                by providing access to data, images, and videos of animals in their
                natural habitats.
              </p>
              <p>
                Affordability: We offer competitive pricing without compromising
                on the quality of our services.
              </p>
              <p>
                Family-Friendly: Our Virtual zoo websites can be enjoyed by people of 
                all ages, making them an excellent option for families to explore
                together and learn about wildlife conservation.
              </p>
              <div className="btn btn-group">
                <NavLink to="/contact">
                  <button className="btn"> Connect Now</button>
                </NavLink>
                <button className="btn secondary-btn">learn more</button>
              </div>
            </div>
            <div className="hero-image">
              <img
                src="/images/polar_bear_PNG23526.png"
                alt="coding buddies "
                width="600"
                height="800"
              />
            </div>
          </div>
        </section>
      </main>

      <Analytics />
    </>
  );
};
