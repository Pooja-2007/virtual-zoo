import { useAuth } from "../store/auth";
import { NavLink } from "react-router-dom";
import { Analytics } from "../components/Analytics";


export const Library = () => {
    const { user } = useAuth();
    return (
    <>
    <main>



   
   
                <section className="section-hero">
                    <div className="container grid grid-two-cols">
                        <div className="hero-content">
                    <img src="/images/animal_1.jpg" alt="our services info" width="200" />
                    <h2>
                        <p float="center">NAME : Chameleons</p>
                        <p>
                            DESCRIPTION : Chameleons or chamaeleons are a distinctive 
                            highly specialized clade of Old World lizards with 200 species
                            described as of June 2015. The members of this family are best
                            known for their distinct range of colours, being capable of
                            colour-shifting camouflage.
                        </p>
                    </h2>
                </div>
                <br></br>
                <div className="card-img2">
                    <img
                        src="/images/animals_2.jpg"
                        alt="our services info"
                        width="200"
                    />
                    <h2>
                        <p float="center">NAME : ZEBRA</p>
                        <p>
                            DESCRIPTION : Zebras are equids, members of the horse family. They
                            have excellent hearing and eyesight and can run at speeds of up to
                            35 miles per hour (56 kilometers per hour). They also have a very
                            powerful kick that can cause serious injury to a predator, like a
                            lion, a hyena, or an African wild dog.
                        </p>
                    </h2>
                </div>
                <br></br>
                <div className="card-img3">
                    <img
                        src="/images/animals_3.jpg"
                        alt="our services info"
                        width="200"
                    />
                    <h2>
                        <p float="center">NAME : GIRAFFE</p>
                        <p>
                            DESCRIPTION : The giraffe is a large African hoofed mammal
                            belonging to the genus Giraffa. It is the tallest living
                            terrestrial animal and the largest ruminant on Earth.
                        </p>
                    </h2>
                </div>

                <br></br>
                <div className="card-img">
                    <img
                        src="/images/leopard.png"
                        alt="our services info"
                        width="200"
                        float="right"
                    />

                    <h2>
                        <p float="center">NAME : LEOPARD</p>
                        <p>
                            DESCRIPTION : The leopard is a slender and muscular cat, with
                            relatively short limbs and a broad head. It is sexually dimorphic
                            with males larger and heavier than females. Males stand 60–70 cm
                            (24–28 in) at the shoulder, while females are 57–64 cm (22–25 in)
                            tall.
                        </p>
                    </h2>
                </div>
            </div>
    

   
            
        </section>
        </main >

            <Analytics />
    </>
    );
};