import { Analytics } from "../components/Analytics";

export const Home = () => {
  return (
    <>
      <main>
        <section className="section-hero">
          <div className="container grid grid-two-cols">
            <div className="hero-content">
             
              <h1>
                Here You Can Find All The Most Unique And Popular Species</h1>
               
              
              <p>
                Welcome To Our Virtual Zoo, Where You Can Embark On An 
                Extraordinary Journey To Explore The World's Most Unique
                And Famous Animals.Our Digital Menagerie Is Your Passport
                To A Global Adventure, Allowing You To Connect With Nature's
                Most Captivating Creatures From The Comfort Of Your Own Home..
              </p>
              <div className="btn btn-group">
                <a href="/contact">
                  <button className="btn">connect now</button>
                </a>
                <a href="/Contact">
                  <button className="btn secondary-btn">learn more</button>
                </a>
              </div>
            </div>

            {/* hero images  */}
            <div className="hero-image">
              <img
                src="/images/leopard.png"
                alt="tiger"
                width="800"
                height="1500"
              />
            </div>
          </div>
        </section>
      </main>

      {/* 2nd section  */}
      <Analytics />

      {/* 3rd section  */}
      <section className="section-hero">
        <div className="container grid grid-two-cols">
          {/* hero images  */}
          <div className="hero-image">
            <img
              src="/images/pngwing.com.png"
              alt="dinasaur"
              width="400"
              height="500"
            />
          </div>

          <div className="hero-content">
            
            <h1>UNLOCK THE SECRETS OF THE PAST: EXPLORE EXTINCT ANIMALS THROUGH 3D MODELS</h1>
            <p>
                Journey Back In Time And Immerse Yourself In The Fascinating World Of 
                Extinct Animals With Our Cutting-Edge 3D Models. Through The Marvels
                Of Technology, We Bring These Ancient Creatures To Life, Allowing You
                To Gain A Deeper Understanding Of Their Forms, Behaviors, And The
                 Ecosystems They Once Inhabited.

            </p>
            <div className="btn btn-group">
              <a href="/contact">
                <button className="btn">connect now</button>
              </a>
              <a href="/services">
                <button className="btn secondary-btn">learn more</button>
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
